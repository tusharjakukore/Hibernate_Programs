package com.hibernate.kolhapur.entity;

public class Payment {
	
	private int p_id;
	private String card_holder_name;
	private int card_no;
	private int CVV;
	private int amount;
	private String date;
	
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Payment(int p_id, String card_holder_name, int card_no, int cVV, int amount, String date) {
		super();
		this.p_id = p_id;
		this.card_holder_name = card_holder_name;
		this.card_no = card_no;
		CVV = cVV;
		this.amount = amount;
		this.date = date;
	}

	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	public String getCard_holder_name() {
		return card_holder_name;
	}

	public void setCard_holder_name(String card_holder_name) {
		this.card_holder_name = card_holder_name;
	}

	public int getCard_no() {
		return card_no;
	}

	public void setCard_no(int card_no) {
		this.card_no = card_no;
	}

	public int getCVV() {
		return CVV;
	}

	public void setCVV(int cVV) {
		CVV = cVV;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Payment [p_id=" + p_id + ", card_holder_name=" + card_holder_name + ", card_no=" + card_no + ", CVV="
				+ CVV + ", amount=" + amount + ", date=" + date + "]";
	}
	
	
	
	
	
	
	
	

}

package com.hibernate.kolhapur.entity;

public class Feedback {
	
	private int f_id;
	private String name;
	private String message;
	private int contact;
	private String f_date;
	
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Feedback(int f_id, String name, String message, int contact, String f_date) {
		super();
		this.f_id = f_id;
		this.name = name;
		this.message = message;
		this.contact = contact;
		this.f_date = f_date;
	}

	public int getF_id() {
		return f_id;
	}

	public void setF_id(int f_id) {
		this.f_id = f_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getContact() {
		return contact;
	}

	public void setContact(int contact) {
		this.contact = contact;
	}

	public String getF_date() {
		return f_date;
	}

	public void setF_date(String f_date) {
		this.f_date = f_date;
	}

	@Override
	public String toString() {
		return "Feedback [f_id=" + f_id + ", name=" + name + ", message=" + message + ", contact=" + contact
				+ ", f_date=" + f_date + "]";
	}
	
	
	
	
	

}

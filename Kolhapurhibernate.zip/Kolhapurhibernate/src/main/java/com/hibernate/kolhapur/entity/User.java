package com.hibernate.kolhapur.entity;


public class User {

	
	private int u_id;
	private String first_name;
	private String last_name;
	private String email;
	private int contact;
	private String address;
	private String username;
	private String password;
	
	
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public User(int u_id, String first_name, String last_name, String email, int contact, String address, String username,
			String password)
	{
		super();
		this.u_id = u_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.email = email;
		this.contact = contact;
		this.address = address;
		this.username = username;
		this.password = password;
	}
	public int getId() {
		return u_id;
	}
	public void setId(int id) {
		this.u_id = id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getContact() {
		return contact;
	}
	public void setContact(int contact) {
		this.contact = contact;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "User [u_id=" + u_id + ", first_name=" + first_name + ", last_name=" + last_name + ", email=" + email
				+ ", contact=" + contact + ", address=" + address + ", username=" + username + ", password=" + password
				+ "]";
	}
	
	
	
	
	
	
}

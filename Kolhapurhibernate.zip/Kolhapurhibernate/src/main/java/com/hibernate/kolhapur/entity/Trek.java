package com.hibernate.kolhapur.entity;

public class Trek {
	private int t_id;
	private String trek_name;
	private String location;
	private String duration;
	private int price;
	private String discription;
	
	public Trek() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Trek(int t_id, String trek_name, String location, String duration, int price, String discription) {
		super();
		this.t_id = t_id;
		this.trek_name = trek_name;
		this.location = location;
		this.duration = duration;
		this.price = price;
		this.discription = discription;
	}

	public int getT_id() {
		return t_id;
	}

	public void setT_id(int t_id) {
		this.t_id = t_id;
	}

	public String getTrek_name() {
		return trek_name;
	}

	public void setTrek_name(String trek_name) {
		this.trek_name = trek_name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getDiscription() {
		return discription;
	}

	public void setDiscription(String discription) {
		this.discription = discription;
	}

	@Override
	public String toString() {
		return "Trek [t_id=" + t_id + ", trek_name=" + trek_name + ", location=" + location + ", duration=" + duration
				+ ", price=" + price + ", discription=" + discription + "]";
	}

	
	
	
	

}

package com.hibernate.kolhapur.entity;

public class Admin {
	
	private int a_id;
	private String name;
	private String email;
	private int contact;
	private String address;
	private String username;
	private String password;
	
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(int a_id, String name, String email, int contact, String address, String username, String password) {
		super();
		this.a_id = a_id;
		this.name = name;
		this.email = email;
		this.contact = contact;
		this.address = address;
		this.username = username;
		this.password = password;
	}

	public int getA_id() {
		return a_id;
	}

	public void setA_id(int a_id) {
		this.a_id = a_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getContact() {
		return contact;
	}

	public void setContact(int contact) {
		this.contact = contact;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Admin [a_id=" + a_id + ", name=" + name + ", email=" + email + ", contact=" + contact + ", address="
				+ address + ", username=" + username + ", password=" + password + "]";
	}
	
	
	
	
	
	

}

package com.hibernate.kolhapur.entity;

public class TrekSchedule {
	
	private int s_id;
	private String start_point;
	private String end_point;
	private String availablity;
	private int total_seat;
	private String date;
	
	public TrekSchedule() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public TrekSchedule(int s_id, String start_point, String end_point, String availablity, int total_seat,
			String date) {
		super();
		this.s_id = s_id;
		this.start_point = start_point;
		this.end_point = end_point;
		this.availablity = availablity;
		this.total_seat = total_seat;
		this.date = date;
	}


	public int getS_id() {
		return s_id;
	}


	public void setS_id(int s_id) {
		this.s_id = s_id;
	}


	public String getStart_point() {
		return start_point;
	}


	public void setStart_point(String start_point) {
		this.start_point = start_point;
	}


	public String getEnd_point() {
		return end_point;
	}


	public void setEnd_point(String end_point) {
		this.end_point = end_point;
	}


	public String getAvailablity() {
		return availablity;
	}


	public void setAvailablity(String availablity) {
		this.availablity = availablity;
	}


	public int getTotal_seat() {
		return total_seat;
	}


	public void setTotal_seat(int total_seat) {
		this.total_seat = total_seat;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	@Override
	public String toString() {
		return "TrekSchedule [s_id=" + s_id + ", start_point=" + start_point + ", end_point=" + end_point
				+ ", availablity=" + availablity + ", total_seat=" + total_seat + ", date=" + date + "]";
	}

	
	
    
}
